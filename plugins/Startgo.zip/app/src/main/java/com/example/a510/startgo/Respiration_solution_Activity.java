package com.example.a510.startgo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Respiration_solution_Activity extends AppCompatActivity {
    WebView respiration_solution_webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.respiration_solution);
        setTitle("S.O.S");
        final String[] menu = {"성인/소아 기도폐쇄", "영아 기도폐쇄"};
        final String[] Url = {"http://www.e-gen.or.kr/egen/first_aid_basics.do?contentsno=19", "http://www.e-gen.or.kr/egen/first_aid_basics.do?contentsno=20"};
        Spinner spinner = (Spinner) findViewById(R.id.respiration_solution_spinner);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, menu);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                respiration_solution_webView = (WebView) findViewById(R.id.respiration_solution_webView);
                respiration_solution_webView.setWebViewClient(new Respiration_solution_Activity.RespirationSolutionWebViewClient());
                respiration_solution_webView.loadUrl(Url[i]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    class RespirationSolutionWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuItem1:
                Intent intent = new Intent(getApplicationContext(), First_main_Activity.class);
                startActivity(intent);
                return true;
            case R.id.menuItem2:
                Intent intent1 = new Intent(getApplicationContext(), Developer_Activity.class);
                startActivity(intent1);
                return true;
            case R.id.menuItem3:
                Intent intent2 = new Intent(getApplicationContext(), LogoutActivity.class);
                startActivity(intent2);
                return true;
        }
        return false;
    }
};