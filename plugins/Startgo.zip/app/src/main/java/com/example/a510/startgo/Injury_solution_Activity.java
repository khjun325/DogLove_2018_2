package com.example.a510.startgo;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Injury_solution_Activity extends AppCompatActivity {
    WebView injury_solution_webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.injury_solution);
        setTitle("S.O.S");
        final String[] menu = {"출혈", "상처", "절단"};
        final String[] Url = {"http://www.e-gen.or.kr/egen/etc_emergency_symptom.do?contentsno=53", "http://www.e-gen.or.kr/egen/etc_emergency_symptom.do?contentsno=54", "http://www.e-gen.or.kr/egen/etc_emergency_symptom.do?contentsno=55"};

        Spinner spinner = (Spinner) findViewById(R.id.injury_solution_spinner);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, menu);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                injury_solution_webView = (WebView) findViewById(R.id.injury_solution_webView);
                injury_solution_webView.setWebViewClient(new InjurySolutionWebViewClient());
                // injury_solution_webView.loadUrl("http://www.e-gen.or.kr/egen/etc_emergency_symptom.do?contentsno=53");

                injury_solution_webView.loadUrl(Url[i]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }

    class InjurySolutionWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuItem1:
                Intent intent = new Intent(getApplicationContext(), First_main_Activity.class);
                startActivity(intent);
                return true;
            case R.id.menuItem2:
                Intent intent1 = new Intent(getApplicationContext(), Developer_Activity.class);
                startActivity(intent1);
                return true;
            case R.id.menuItem3:
                Intent intent2 = new Intent(getApplicationContext(), LogoutActivity.class);
                startActivity(intent2);
                return true;
        }
        return false;
    }
}
