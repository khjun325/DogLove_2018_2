package com.example.a510.startgo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

@SuppressWarnings("deprecation")
public class Heart_stop_solution_Activity extends AppCompatActivity {
    WebView heart_stop_webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.heart_stop_solution);
        setTitle("S.O.S");
        final String[] menu = {"심폐소생술/ AED사용법", "성인 심폐소생술", "소아 심폐소생술"};
        final String[] Url = {"http://www.e-gen.or.kr/egen/aed_usage.do", "http://www.e-gen.or.kr/egen/first_aid_basics.do?contentsno=17", "http://www.e-gen.or.kr/egen/first_aid_basics.do?contentsno=18"};
        Spinner spinner = (Spinner) findViewById(R.id.heart_stop_solution_spinner);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, menu);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                heart_stop_webView = (WebView) findViewById(R.id.heart_stop_webView);
                heart_stop_webView.setWebViewClient(new Heart_stop_solution_Activity.HeartStopWebViewClient());
                heart_stop_webView.loadUrl(Url[i]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    class HeartStopWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuItem1:
                Intent intent = new Intent(getApplicationContext(), First_main_Activity.class);
                startActivity(intent);
                return true;
            case R.id.menuItem2:
                Intent intent1 = new Intent(getApplicationContext(), Developer_Activity.class);
                startActivity(intent1);
                return true;
            case R.id.menuItem3:
                Intent intent2 = new Intent(getApplicationContext(), LogoutActivity.class);
                startActivity(intent2);
                return true;
        }
        return false;
    }
}